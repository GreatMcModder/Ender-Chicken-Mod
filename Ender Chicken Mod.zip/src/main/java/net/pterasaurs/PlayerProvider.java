package net.pterasaurs;

public interface PlayerProvider{
    void sendMessage1(int i);
}
