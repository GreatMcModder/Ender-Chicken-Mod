package net.pterasaurs;

import net.fabricmc.api.ModInitializer;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.pterasaurs.block.ModBlocks;
import net.pterasaurs.entity.EnderChickenEntity;
import net.pterasaurs.entity.EnderChickenMinion;
import net.pterasaurs.entity.UltimateChickenEntity;
import net.pterasaurs.item.EnderEggEntity;
import net.pterasaurs.item.ModItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EnderChicken implements ModInitializer {
	public static final String MOD_ID = "ender-chicken";
	public static final EntityType<EnderChickenEntity> END_CHICKEN = Registry.register(Registries.ENTITY_TYPE,
			Identifier.of(EnderChicken.MOD_ID, "ender_chicken"),
			EntityType.Builder.create(EnderChickenEntity::new, SpawnGroup.MISC)
					.dimensions(1f, 0.75f).build("ender_chicken"));

	public static final EntityType<UltimateChickenEntity> ULTIMA_CHICKEN = Registry.register(Registries.ENTITY_TYPE,
			Identifier.of(EnderChicken.MOD_ID, "ultimate_chicken"),
			EntityType.Builder.create(UltimateChickenEntity::new, SpawnGroup.MISC)
					.dimensions(1f, 0.75f).build("ultimate_chicken"));

	public static final EntityType<EnderEggEntity> EGG = Registry.register(Registries.ENTITY_TYPE,
			Identifier.of(EnderChicken.MOD_ID, "ender_egg"),
			EntityType.Builder.create(EnderEggEntity::new, SpawnGroup.MISC)
					.dimensions(0.25f, 0.25f).build("ender_egg"));
	public static final EntityType<EnderChickenMinion> MINION = Registry.register(Registries.ENTITY_TYPE,
			Identifier.of(EnderChicken.MOD_ID, "ender_chicken_minion"),
			EntityType.Builder.create(EnderChickenMinion::new, SpawnGroup.MISC)
					.dimensions(1f, 0.75f).build("ender_chicken_minion"));
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
	@Override
	public void onInitialize() {
		ModBlocks.initialize();
		ModItem.init();
		FabricDefaultAttributeRegistry.register(ULTIMA_CHICKEN,UltimateChickenEntity.setMobAttributes());
		FabricDefaultAttributeRegistry.register(END_CHICKEN, EnderChickenEntity.setMobAttributes());
		FabricDefaultAttributeRegistry.register(MINION, EnderChickenMinion.setMobAttributes());
		LOGGER.info("Hello Fabric world!");
	}
}