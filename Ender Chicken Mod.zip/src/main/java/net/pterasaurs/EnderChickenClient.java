package net.pterasaurs;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.FlyingItemEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;
import net.pterasaurs.entity.*;

@Environment(EnvType.CLIENT)
public class EnderChickenClient implements ClientModInitializer {
    public static final EntityModelLayer END_CHICKEN =
            new EntityModelLayer(Identifier.of(EnderChicken.MOD_ID, "ender_chicken"),"main");
    public static final EntityModelLayer MINION =
            new EntityModelLayer(Identifier.of(EnderChicken.MOD_ID, "ender_chicken_minion"),"main");
    public static final EntityModelLayer ULTIMATE_CHICKEN =
            new EntityModelLayer(Identifier.of(EnderChicken.MOD_ID, "ultimate_chicken"),"main");
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(EnderChicken.EGG, FlyingItemEntityRenderer::new);
        EntityRendererRegistry.register(EnderChicken.END_CHICKEN, (EnderChickenRenderer::new));
        EntityModelLayerRegistry.registerModelLayer(END_CHICKEN, EnderChickenModel::getTexturedModelData);
        EntityRendererRegistry.register(EnderChicken.MINION, (EnderChickenMinionRenderer::new));
        EntityModelLayerRegistry.registerModelLayer(MINION, MinionModel::getTexturedModelData);
        EntityRendererRegistry.register(EnderChicken.ULTIMA_CHICKEN, (UltimateChickenRender::new));
        EntityModelLayerRegistry.registerModelLayer(ULTIMATE_CHICKEN, UltimateChickenModel::getTexturedModelData);
    }
}