package net.pterasaurs.item;

import net.minecraft.item.EggItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.pterasaurs.EnderChicken;

public class ModItem {
    public static Item register(Item item, String id) {
        // Create the identifier for the item.
        Identifier itemID = Identifier.of(EnderChicken.MOD_ID, id);

        // Register the item.
        Item registeredItem = Registry.register(Registries.ITEM, itemID, item);

        // Return the registered item!
        return registeredItem;
    }
    public static void init() {}
    public static final Item ENDER_EGG = register(
            new EnderEggItem(new Item.Settings()),
            "ender_egg"
    );
}
