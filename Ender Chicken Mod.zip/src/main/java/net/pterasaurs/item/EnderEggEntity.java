package net.pterasaurs.item;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.passive.WolfEntity;
import net.minecraft.entity.projectile.thrown.ThrownItemEntity;
import net.minecraft.item.Item;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.World;
import net.pterasaurs.EnderChicken;
import net.pterasaurs.entity.EnderChickenEntity;

public class EnderEggEntity extends ThrownItemEntity {
    public EnderEggEntity(EntityType<? extends ThrownItemEntity> entityType, World world) {
        super(entityType, world);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItem.ENDER_EGG;
    }
    protected void onCollision(HitResult hitResult) {
        EnderChickenEntity chickenEntity = EnderChicken.END_CHICKEN.create(this.getWorld());
        if (chickenEntity != null) {
            chickenEntity.setPersistent();
            chickenEntity.refreshPositionAndAngles(this.getX(), this.getY(), this.getZ(), this.getYaw(), 0.0F);
            chickenEntity.setHealt(chickenEntity.getMaxHealt());
            this.getWorld().spawnEntity(chickenEntity);
        }
        this.kill();
    }
}