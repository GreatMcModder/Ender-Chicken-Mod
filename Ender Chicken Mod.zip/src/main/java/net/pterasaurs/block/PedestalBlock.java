package net.pterasaurs.block;

import net.minecraft.block.*;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;
import net.pterasaurs.EnderChicken;
import net.pterasaurs.entity.EnderChickenMinion;
import net.pterasaurs.item.ModItem;

public class PedestalBlock extends Block {
    public PedestalBlock(Settings settings) {
        super(settings);
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (player.getMainHandStack().isOf(Items.DRAGON_EGG) && !player.getWorld().isClient) {
            ServerWorld serverWorld = (ServerWorld) player.getWorld();
            player.getMainHandStack().decrement(1);
            for (int i = 0; i < 1; i++) {
                ItemEntity clone = (ItemEntity) EntityType.ITEM.create(serverWorld);
                if (clone != null) {
                    clone.setStack(ModItem.ENDER_EGG.getDefaultStack());
                    clone.refreshPositionAndAngles(pos.getX(), pos.getY() + 1, pos.getZ(), 0.0F, 0.0F);
                    serverWorld.spawnEntityAndPassengers(clone);
                    serverWorld.emitGameEvent(GameEvent.ENTITY_PLACE, pos, GameEvent.Emitter.of(player));
                }
            }
        }
        return ActionResult.PASS;
    }
}