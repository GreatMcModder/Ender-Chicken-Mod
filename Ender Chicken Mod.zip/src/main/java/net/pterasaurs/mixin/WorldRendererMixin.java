package net.pterasaurs.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.pterasaurs.EnderChicken;
import net.pterasaurs.entity.EnderChickenEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(BackgroundRenderer.class)
public class WorldRendererMixin {

    @Shadow
    private static float red;
    @Shadow
    private static float green;
    @Shadow
    private static float blue;

    @Inject(method = "render("
            + "Lnet/minecraft/client/render/Camera;"
            + "F"
            + "Lnet/minecraft/client/world/ClientWorld;"
            + "I"
            + "F"
            + ")V",
            at = @At("RETURN"))
    private static void onUpdateColorNotInWater(Camera camera, float tickDelta, ClientWorld world, int renderDistance, float skyDarkness, CallbackInfo info) {
        PlayerEntity entity = (PlayerEntity) camera.getFocusedEntity();
        Box boundingBox = entity.getBoundingBox().expand(64);
        List<EnderChickenEntity> entitiesInRadius = entity.getWorld().getEntitiesByClass(EnderChickenEntity.class, boundingBox, x -> true);
        if (!entitiesInRadius.isEmpty()) {
            changeFogColour(10);
        }
    }

    private static void changeFogColour(double factor) {
        red *= factor/4;
        green *= factor/4;
        blue *= (factor+150);
        RenderSystem.clearColor(red, green, blue, 0);
    }
}