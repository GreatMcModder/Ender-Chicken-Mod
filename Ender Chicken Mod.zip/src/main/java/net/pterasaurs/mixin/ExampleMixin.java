package net.pterasaurs.mixin;

import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.thrown.EggEntity;
import net.minecraft.entity.projectile.thrown.SnowballEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.pterasaurs.PlayerProvider;
import net.pterasaurs.block.ModBlocks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EnderDragonEntity.class)
public abstract class ExampleMixin extends MobEntity {
	protected ExampleMixin(EntityType<? extends MobEntity> entityType, World world) {
		super(entityType, world);
	}

	@Inject(method = "kill",at = @At("HEAD"))
	public void onDead(CallbackInfo ci) {
		BlockPos placement = new BlockPos(0,100,0);
		this.getWorld().setBlockState(placement, ModBlocks.EGG_PEDESTAL.getDefaultState());
	}
	@Inject(method = "updatePostDeath",at = @At("HEAD"))
	public void init(CallbackInfo ci) {
		BlockPos placement = new BlockPos(0,100,0);
		this.getWorld().setBlockState(placement, ModBlocks.EGG_PEDESTAL.getDefaultState());
	}
}