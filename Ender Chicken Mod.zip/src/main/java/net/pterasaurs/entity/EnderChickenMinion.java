package net.pterasaurs.entity;

import net.minecraft.client.render.entity.WitherSkullEntityRenderer;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;

public class EnderChickenMinion extends HostileEntity {
    public EnderChickenMinion(EntityType<? extends HostileEntity> entityType, World world) {
        super(entityType, world);
    }
    public static DefaultAttributeContainer.Builder setMobAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 1024.0F)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.34F)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 17.0F)
                .add(EntityAttributes.GENERIC_ARMOR, 0.0F)
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 7.0F);
    }

    @Override
    protected void initGoals() {
        super.initGoals();
        this.goalSelector.add(1, new SwimGoal(this));
        this.goalSelector.add(0, new MeleeAttackGoal(this, 1.0D, false));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.8));
        this.targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
        this.targetSelector.add(2, new RevengeGoal(this));
    }
}