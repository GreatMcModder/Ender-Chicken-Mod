package net.pterasaurs.entity;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RedstoneLampBlock;
import net.minecraft.client.render.entity.SlimeEntityRenderer;
import net.minecraft.client.render.entity.WitherSkullEntityRenderer;
import net.minecraft.entity.*;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageType;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.command.PlaceCommand;
import net.minecraft.server.command.SetBlockCommand;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.event.GameEvent;
import net.minecraft.world.explosion.Explosion;
import net.minecraft.world.gen.feature.EndPortalFeature;
import net.minecraft.world.gen.structure.OceanRuinStructure;
import net.pterasaurs.EnderChicken;
import org.jetbrains.annotations.Nullable;

import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class EnderChickenEntity extends HostileEntity {
    private final int maxHealth = 9000;
    @Nullable
    private LivingEntity attackr;
    public int getMaxHealt() {
        return this.maxHealth;
    }
    private static final TrackedData<Boolean> shouldUpdateCluck = DataTracker.registerData(EnderChickenEntity.class,TrackedDataHandlerRegistry.BOOLEAN);
    private final ServerBossBar bossBar;
    public final AnimationState summon_animation = new AnimationState();
    public final AnimationState cluck_of_death = new AnimationState();
    private float healt;
    private int serverTest;
    private static final TrackedData<Integer> CREATIVE_TIMER = DataTracker.registerData(EnderChickenEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> ATTACK_TIMER = DataTracker.registerData(EnderChickenEntity.class, TrackedDataHandlerRegistry.INTEGER);
    public EnderChickenEntity(EntityType<? extends HostileEntity> entityType, World world) {
        super(entityType, world);
        this.bossBar = (ServerBossBar) (new ServerBossBar(this.getDisplayName(), BossBar.Color.PURPLE, BossBar.Style.NOTCHED_6)).setDarkenSky(false);
    }

    public static DefaultAttributeContainer.Builder setMobAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 1024.0F)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.34F)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 1024.0F)
                .add(EntityAttributes.GENERIC_ARMOR, 0.0F)
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 1.0F);
    }

    public void setHealt(float i) {
        this.healt = i;
    }

    @Override
    public void onDeath(DamageSource source) {
        if (source.getAttacker() != null) {
            if (this.getAttackr() != null && this.getAttackr() instanceof PlayerEntity && !this.getWorld().isClient) {
                ServerWorld serverWorld = (ServerWorld) this.getWorld();
                for (int i = 0; i < 1; i++) {
                    UltimateChickenEntity clone = (UltimateChickenEntity) EnderChicken.ULTIMA_CHICKEN.create(serverWorld);
                    if (clone != null) {
                        clone.setOwner(this.getWorld().getClosestPlayer(this,32));
                        clone.refreshPositionAndAngles(this.getX(), this.getY(), this.getZ(), 0.0F, 0.0F);
                        serverWorld.spawnEntityAndPassengers(clone);
                        serverWorld.emitGameEvent(GameEvent.ENTITY_PLACE, this.getBlockPos(), GameEvent.Emitter.of(this));
                    }
                }
            }
        }
        super.onDeath(source);
    }

    public float getHealt() {
        return this.healt;
    }
    public void setAttackTimer(int i) {
        this.dataTracker.set(ATTACK_TIMER,i);
    }
    public int getAttackTimer() {
        return this.dataTracker.get(ATTACK_TIMER);
    }
    @Override
    public @Nullable EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason spawnReason, @Nullable EntityData entityData) {
        this.setHealt(maxHealth);
        this.setPersistent();
        return super.initialize(world, difficulty, spawnReason, entityData);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        this.healt = nbt.getFloat("Healt");
        this.dataTracker.set(shouldUpdateCluck,nbt.getBoolean("Clucking"));
        this.serverTest=nbt.getInt("ServerTest");
        this.setAttackTimer(nbt.getInt("AttackTimer"));
        this.dataTracker.set(CREATIVE_TIMER, nbt.getInt("CreativeTimer"));
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putFloat("Healt", this.healt);
        nbt.putBoolean("Clucking",this.dataTracker.get(shouldUpdateCluck));
        nbt.putInt("AttackTimer",this.getAttackTimer());
        nbt.putInt("ServerTest", this.serverTest);
        nbt.putInt("CreativeTimer", this.dataTracker.get(CREATIVE_TIMER));
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(CREATIVE_TIMER, 0);
        builder.add(shouldUpdateCluck,false);
        builder.add(ATTACK_TIMER, 0);
    }

    @Override
    protected void initGoals() {
        super.initGoals();
        this.goalSelector.add(1, new SwimGoal(this));
        this.goalSelector.add(0, new MeleeAttackGoal(this, 1.0D, false));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.8));
        this.targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
        this.targetSelector.add(2, new RevengeGoal(this));
    }
    @Nullable
    public LivingEntity getAttackr() {
        return this.attackr;
    }

    @Override
    public void setCustomName(@Nullable Text name) {
        super.setCustomName(name);
        this.bossBar.setName(this.getDisplayName());
    }
    protected void killPlayer() {
        if (!this.getWorld().isClient) {
            Box boundingBox = this.getBoundingBox().expand(16);
            List<PlayerEntity> entitiesInRadius = this.getWorld().getEntitiesByClass(PlayerEntity.class, boundingBox, x -> true);

            for (PlayerEntity entity : entitiesInRadius) {
                if (entity.isCreative()) {
                    if (this.dataTracker.get(CREATIVE_TIMER)==200) {
                        entity.kill();
                        entity.sendMessage(Text.literal("<Ender Chicken> YOU ARE FOOL!"));
                    }
                    if (this.dataTracker.get(CREATIVE_TIMER)==100) {
                        entity.sendMessage(Text.literal("<Ender Chicken> Do you really think you can cheat?"));
                    }
                }
            }
            LivingEntity target = this.getTarget();
            if (this.getAttackTimer()==517 && target != null && Math.abs(this.getX()-target.getX())<16 && Math.abs(this.getZ()-target.getZ())<16) {
                target.kill();
                if (target instanceof PlayerEntity) {
                    target.sendMessage(Text.literal("<Ender Chicken> That was my unbeatable cluck of death!"));
                }
            }
        }
    }
    private void updateAnimations() {
        if (this.dataTracker.get(shouldUpdateCluck)) {
                this.cluck_of_death.startIfNotRunning(this.age);
        } else {
            this.cluck_of_death.stop();
        }
    }
    @Override
    public void tick() {
        super.tick();
        if (this.getWorld().isClient) {
            this.updateAnimations();
        }
        if (this.getAttackr() != null && this.getAttackr().isAlive()) {
            this.setTarget(this.getAttackr());
        }
        LivingEntity target = this.getTarget();
        if (target != null && !this.getWorld().isClient) {
            if (this.getAttackTimer() == 200) {
                ServerWorld serverWorld = (ServerWorld) this.getWorld();
                for (int i = 0; i < 7; i++) {
                    EnderChickenMinion clone = (EnderChickenMinion) EnderChicken.MINION.create(serverWorld);
                    if (clone != null) {
                        clone.refreshPositionAndAngles(this.getX(), this.getY() + 1, this.getZ(), 0.0F, 0.0F);
                        serverWorld.spawnEntityAndPassengers(clone);
                        serverWorld.emitGameEvent(GameEvent.ENTITY_PLACE, this.getBlockPos(), GameEvent.Emitter.of(this));
                    }
                }
                this.setAttackTimer(201);
            } else if (this.getAttackTimer()==500) {
                this.dataTracker.set(shouldUpdateCluck,true);
                this.setAttackTimer(501);
            } else if (this.getAttackTimer()==517) {
                this.killPlayer();
                this.dataTracker.set(shouldUpdateCluck,false);
                this.setAttackTimer(518);
            } else if (this.getAttackTimer()==615) {
                this.getWorld().createExplosion(this, Explosion.createDamageSource(this.getWorld(), this), null, this.getX(), this.getY(), this.getZ(), 17.0F, true, World.ExplosionSourceType.MOB);
                this.setPos(target.getX(), target.getY() + 7, target.getZ());
                Iterator<BlockPos> blockPosToChange =
                        BlockPos.iterateOutwards(this.getBlockPos(),
                                (int) (7), 7, (int) (7)).iterator();
                for (Iterator<BlockPos> it = blockPosToChange; it.hasNext(); ) {
                    BlockPos position = it.next();
                    this.getWorld().setBlockState(position, Blocks.AIR.getDefaultState());
                }
                this.setAttackTimer(0);
            }
            else{
                this.setAttackTimer(this.getAttackTimer() + 1);
            }
        }
        this.bossBar.setPercent(this.getHealt() / maxHealth);
        if (this.dataTracker.get(CREATIVE_TIMER)==200) {
            this.killPlayer();
            this.dataTracker.set(CREATIVE_TIMER, 0);
        }else if (this.dataTracker.get(CREATIVE_TIMER)==100) {
            this.killPlayer();
            this.dataTracker.set(CREATIVE_TIMER, 101);
        } else {
            this.dataTracker.set(CREATIVE_TIMER,this.dataTracker.get(CREATIVE_TIMER)+1);
        }
        if (this.getHealt() < maxHealth && this.getHealt()>0) {
            this.setHealt(this.getHealt() + 0.05F);
        }
        if (this.getHealt() <= 0) {
            this.kill();
        }
        // Debugging log
        System.out.println("Timer: " + this.dataTracker.get(CREATIVE_TIMER));
        Random random1 = new Random();
        if (random1.nextInt(500)==1) {
            this.broke();
        }
    }
    public void broke() {
        int randomness = (int)(Math.random() * 201);
        Entity enemy = this.getTarget();
        if (enemy != null && enemy.getY()-this.getY() <= 2 && randomness == 5) {
            if (Math.abs(enemy.getX()-this.getX()) >= 0.45 || Math.abs(enemy.getZ()-this.getZ()) >= 0.45 ) {
                boolean bl = false;
                Box box = this.getBoundingBox().expand(0.2);

                for(BlockPos blockPos : BlockPos.iterate(MathHelper.floor(box.minX), MathHelper.floor(box.minY), MathHelper.floor(box.minZ), MathHelper.floor(box.maxX), MathHelper.floor(box.maxY), MathHelper.floor(box.maxZ))) {
                    BlockState blockState = this.getWorld().getBlockState(blockPos);
                    Block block = blockState.getBlock();
                    if (!this.getWorld().getBlockState(blockPos).isOf(Blocks.BEDROCK)) {
                        bl = this.getWorld().breakBlock(blockPos, true, this) || bl;
                    }
                }

                if (!bl && this.isOnGround()) {
                    this.addVelocity(0.0, 0.4, 0.0);
                }
            }
        }
    }
    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        this.bossBar.addPlayer(player);
    }

    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        this.bossBar.removePlayer(player);
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (!(source.getAttacker() instanceof PlayerEntity) && source.getAttacker()!=null) {
            source.getAttacker().kill();
        }
        if (source.isOf(DamageTypes.ARROW) && source.getAttacker()!=null) {
            source.getAttacker().kill();
        }
        if (source.isOf(DamageTypes.FIREWORKS) && source.getAttacker()!=null) {
            source.getAttacker().kill();
        }
        if (!source.isOf(DamageTypes.CRAMMING) && !source.isOf(DamageTypes.OUT_OF_WORLD) && source.getAttacker() != null && Math.abs(source.getAttacker().getX()-this.getX())<16 && Math.abs(source.getAttacker().getY()-this.getY())<16 && Math.abs(source.getAttacker().getZ()-this.getZ())<16 && !source.isOf(DamageTypes.EXPLOSION)) {
            this.healt -= Math.min(amount, 6.0F);
            if (source.getAttacker() != null && source.getAttacker() instanceof LivingEntity) {
                LivingEntity attacks = (LivingEntity) source.getAttacker();
                this.attackr=attacks;
            }
        }
        if (this.getHealt()<=0) {
            return super.damage(source,amount);
        } else {
            return false;
        }
    }
}
