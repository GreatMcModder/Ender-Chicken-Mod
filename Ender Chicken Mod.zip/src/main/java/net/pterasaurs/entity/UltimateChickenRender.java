package net.pterasaurs.entity;

import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;
import net.pterasaurs.EnderChicken;
import net.pterasaurs.EnderChickenClient;

public class UltimateChickenRender extends MobEntityRenderer<UltimateChickenEntity, UltimateChickenModel> {
    public UltimateChickenRender(EntityRendererFactory.Context context) {
        super(context, new UltimateChickenModel(context.getPart(EnderChickenClient.ULTIMATE_CHICKEN)), 0.5f);
    }

    @Override
    public Identifier getTexture(UltimateChickenEntity entity) {
        return Identifier.of(EnderChicken.MOD_ID,"textures/entity/ultimate_chicken.png");
    }
}
