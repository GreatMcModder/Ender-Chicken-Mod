package net.pterasaurs.entity;

import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.AttackWithOwnerGoal;
import net.minecraft.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class UltimateChickenEntity extends TameableEntity {
    private static final TrackedData<Integer> COOLDOWN = DataTracker.registerData(UltimateChickenEntity.class, TrackedDataHandlerRegistry.INTEGER);
    public UltimateChickenEntity(EntityType<? extends TameableEntity> entityType, World world) {
        super(entityType, world);
    }
    public static DefaultAttributeContainer.Builder setMobAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 1024.0F)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.24F)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 124.0F)
                .add(EntityAttributes.GENERIC_ARMOR, 0.0F)
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 1000.0F);
    }

    @Override
    public @Nullable PassiveEntity createChild(ServerWorld world, PassiveEntity entity) {
        return null;
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(COOLDOWN,0);
    }

    @Override
    public ActionResult interactMob(PlayerEntity player, Hand hand) {
        ItemStack mainHand = player.getStackInHand(hand);
        if (this.getTarget() != null) {
            if (mainHand.isOf(Items.NETHERITE_INGOT) && this.dataTracker.get(COOLDOWN)<=0 && this.squaredDistanceTo(this.getTarget())<64) {
                this.getTarget().kill();
                mainHand.decrement(1);
                this.dataTracker.set(COOLDOWN,200);
            }
    }
        return super.interactMob(player, hand);
    }
    @Override
    public void tick() {
        super.tick();
        this.dataTracker.set(COOLDOWN,this.dataTracker.get(COOLDOWN)-1);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        this.dataTracker.set(COOLDOWN, nbt.getInt("Cooldown"));
        super.readCustomDataFromNbt(nbt);
    }

    @Override
    public EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason spawnReason, @Nullable EntityData entityData) {
        this.setOwner(this.getWorld().getClosestPlayer(this,32));
        return super.initialize(world, difficulty, spawnReason, entityData);
    }

    @Override
    public boolean isBreedingItem(ItemStack stack) {
        return false;
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        nbt.putInt("Cooldown",this.dataTracker.get(COOLDOWN));
        super.writeCustomDataToNbt(nbt);
    }
    @Override
    protected void initGoals() {
        super.initGoals();
        this.goalSelector.add(0,new MeleeAttackGoal(this,1d,true));
        this.goalSelector.add(0,new FollowOwnerGoal(this,1d,4,64));
        this.targetSelector.add(0,new AttackWithOwnerGoal(this));
    }
}
