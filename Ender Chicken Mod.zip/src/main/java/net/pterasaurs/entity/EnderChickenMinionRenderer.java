package net.pterasaurs.entity;

import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;
import net.pterasaurs.EnderChicken;
import net.pterasaurs.EnderChickenClient;

public class EnderChickenMinionRenderer extends MobEntityRenderer<EnderChickenMinion, MinionModel> {
    public EnderChickenMinionRenderer(EntityRendererFactory.Context context) {
        super(context, new MinionModel(context.getPart(EnderChickenClient.MINION)), 0.5f);
    }

    @Override
    public Identifier getTexture(EnderChickenMinion entity) {
        return Identifier.of(EnderChicken.MOD_ID,"textures/entity/minion.png");
    }
}
