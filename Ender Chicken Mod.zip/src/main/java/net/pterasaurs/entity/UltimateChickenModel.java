package net.pterasaurs.entity;

import net.minecraft.client.model.*;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.pterasaurs.entity.UltimateChickenEntity;

// Made with Blockbench 4.11.2
// Exported for Minecraft version 1.17+ for Yarn
// Paste this class into your mod and generate all required imports
public class UltimateChickenModel extends SinglePartEntityModel<UltimateChickenEntity> {
	private final ModelPart chicken;
	private final ModelPart leg;
	private final ModelPart head;
	private final ModelPart leg2;
	private final ModelPart body;
	private final ModelPart wing2;
	private final ModelPart wing;
	public UltimateChickenModel(ModelPart root) {
		this.chicken = root.getChild("chicken");
		this.leg = this.chicken.getChild("leg");
		this.head = this.chicken.getChild("head");
		this.leg2 = this.chicken.getChild("leg2");
		this.body = this.chicken.getChild("body");
		this.wing2 = this.body.getChild("wing2");
		this.wing = this.body.getChild("wing");
	}
	public static TexturedModelData getTexturedModelData() {
		ModelData modelData = new ModelData();
		ModelPartData modelPartData = modelData.getRoot();
		ModelPartData chicken = modelPartData.addChild("chicken", ModelPartBuilder.create(), ModelTransform.of(0.0F, 24.0F, 1.0F, 0.0F, 3.1416F, 0.0F));

		ModelPartData leg = chicken.addChild("leg", ModelPartBuilder.create().uv(24, 23).cuboid(-1.0F, -1.0F, -1.0F, 2.0F, 4.0F, 2.0F, new Dilation(0.0F)), ModelTransform.pivot(-2.0F, -3.0F, 0.0F));

		ModelPartData head = chicken.addChild("head", ModelPartBuilder.create().uv(16, 20).cuboid(-3.0F, 0.0F, 4.0F, 4.0F, 1.0F, 2.0F, new Dilation(0.0F))
		.uv(0, 11).cuboid(-3.0F, -2.0F, -1.0F, 4.0F, 4.0F, 5.0F, new Dilation(0.0F)), ModelTransform.pivot(1.0F, -9.0F, 4.0F));

		ModelPartData leg2 = chicken.addChild("leg2", ModelPartBuilder.create().uv(16, 23).cuboid(-1.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F, new Dilation(0.0F)), ModelTransform.pivot(2.0F, -4.0F, 0.0F));

		ModelPartData body = chicken.addChild("body", ModelPartBuilder.create().uv(0, 0).cuboid(-3.0F, -4.0F, -3.0F, 6.0F, 4.0F, 7.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, -4.0F, 0.0F));

		ModelPartData wing2 = body.addChild("wing2", ModelPartBuilder.create().uv(18, 11).cuboid(1.0F, -2.0F, -5.0F, 1.0F, 3.0F, 6.0F, new Dilation(0.0F)), ModelTransform.pivot(2.0F, -2.0F, 3.0F));

		ModelPartData wing = body.addChild("wing", ModelPartBuilder.create().uv(1, 20).cuboid(-1.0F, -1.5F, -5.0F, 1.0F, 3.0F, 6.0F, new Dilation(0.0F)), ModelTransform.pivot(-3.0F, -2.5F, 3.0F));
		return TexturedModelData.of(modelData, 64, 64);
	}
	@Override
	public void setAngles(UltimateChickenEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
		this.getPart().traverse().forEach(ModelPart::resetTransform);
		this.animateMovement(UltimateChickenAnimation.walk, limbSwing, limbSwingAmount, 2.0F, 2.5F);
	}

	@Override
	public ModelPart getPart() {
		return chicken;
	}
}