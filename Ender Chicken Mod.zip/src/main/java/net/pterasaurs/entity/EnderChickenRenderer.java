package net.pterasaurs.entity;

import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.util.Identifier;
import net.pterasaurs.EnderChicken;
import net.pterasaurs.EnderChickenClient;

public class EnderChickenRenderer extends MobEntityRenderer<EnderChickenEntity, EnderChickenModel> {
    public EnderChickenRenderer(EntityRendererFactory.Context context) {
        super(context, new EnderChickenModel(context.getPart(EnderChickenClient.END_CHICKEN)), 0.5f);
    }

    @Override
    public Identifier getTexture(EnderChickenEntity entity) {
        return Identifier.of(EnderChicken.MOD_ID,"textures/entity/ender_chicken.png");
    }
}
