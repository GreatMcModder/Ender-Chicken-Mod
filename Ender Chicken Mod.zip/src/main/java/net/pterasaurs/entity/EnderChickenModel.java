package net.pterasaurs.entity;

import net.minecraft.client.model.*;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.animation.CamelAnimations;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.client.util.math.MatrixStack;

// Made with Blockbench 4.11.2
// Exported for Minecraft version 1.17+ for Yarn
// Paste this class into your mod and generate all required imports
public class EnderChickenModel extends SinglePartEntityModel<EnderChickenEntity> {
	private final ModelPart ender_chicken;
	private final ModelPart leg1;
	private final ModelPart leg0;
	private final ModelPart body;
	private final ModelPart head;
	private final ModelPart beak;
	private final ModelPart beak2;
	private final ModelPart wing1;
	private final ModelPart wing0;
	public EnderChickenModel(ModelPart root) {
		this.ender_chicken = root.getChild("ender_chicken");
		this.leg1 = this.ender_chicken.getChild("leg1");
		this.leg0 = this.ender_chicken.getChild("leg0");
		this.body = this.ender_chicken.getChild("body");
		this.head = this.body.getChild("head");
		this.beak = this.head.getChild("beak");
		this.beak2 = this.head.getChild("beak2");
		this.wing1 = this.body.getChild("wing1");
		this.wing0 = this.body.getChild("wing0");
	}
	public static TexturedModelData getTexturedModelData() {
		ModelData modelData = new ModelData();
		ModelPartData modelPartData = modelData.getRoot();
		ModelPartData ender_chicken = modelPartData.addChild("ender_chicken", ModelPartBuilder.create(), ModelTransform.pivot(0.0F, 24.0F, 0.0F));

		ModelPartData leg1 = ender_chicken.addChild("leg1", ModelPartBuilder.create().uv(0, 62).cuboid(-3.0F, -2.5F, -2.5F, 6.0F, 9.0F, 5.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, -6.5F, -1.5F));

		ModelPartData leg0 = ender_chicken.addChild("leg0", ModelPartBuilder.create().uv(22, 63).cuboid(-2.5F, -2.5F, -2.5F, 5.0F, 9.0F, 5.0F, new Dilation(0.0F)), ModelTransform.pivot(-5.5F, -6.5F, -1.5F));

		ModelPartData body = ender_chicken.addChild("body", ModelPartBuilder.create().uv(0, 0).cuboid(-9.0F, -8.0F, -9.0F, 12.0F, 17.0F, 12.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, -15.0F, 0.0F, 1.5708F, 0.0F, 0.0F));

		ModelPartData head = body.addChild("head", ModelPartBuilder.create().uv(0, 29).cuboid(-8.0F, -10.0F, -8.0F, 10.0F, 12.0F, 9.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, -3.8227F, 0.1271F, -1.6144F, 0.0F, 0.0F));

		ModelPartData beak = head.addChild("beak", ModelPartBuilder.create().uv(0, 50).cuboid(-8.0F, -4.0F, -10.0F, 10.0F, 4.0F, 8.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, 1.0F, -6.0F));

		ModelPartData beak2 = head.addChild("beak2", ModelPartBuilder.create().uv(36, 51).cuboid(-8.0F, -4.0F, -10.0F, 10.0F, 4.0F, 8.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, -3.0F, -6.0F));

		ModelPartData wing1 = body.addChild("wing1", ModelPartBuilder.create().uv(38, 29).cuboid(-1.0F, -4.0F, -12.0F, 4.0F, 10.0F, 12.0F, new Dilation(0.0F)), ModelTransform.of(4.0F, -3.0F, 3.0F, 0.3927F, -0.7854F, 0.0F));

		ModelPartData wing0 = body.addChild("wing0", ModelPartBuilder.create().uv(48, 0).cuboid(-2.5F, -5.0F, -12.0F, 3.0F, 10.0F, 12.0F, new Dilation(0.0F)), ModelTransform.of(-9.5F, -2.0F, 3.0F, 0.5889F, 0.2564F, 0.1678F));
		return TexturedModelData.of(modelData, 128, 128);
	}
	@Override
	public void setAngles(EnderChickenEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
		this.getPart().traverse().forEach(ModelPart::resetTransform);
		this.updateAnimation(entity.cluck_of_death, EnderChickenAnimation.cluck_of_death, ageInTicks, 1.0F);
		this.animateMovement(EnderChickenAnimation.walk, limbSwing, limbSwingAmount, 2.0F, 2.5F);
	}

	@Override
	public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay, int color) {
		ender_chicken.render(matrices, vertices, light, overlay,color);
	}

	@Override
	public ModelPart getPart() {
		return ender_chicken;
	}
}